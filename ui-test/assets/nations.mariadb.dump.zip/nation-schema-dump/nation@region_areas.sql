-- MariaDB Shell dump 2.0.1  Distrib Ver 26.11.2 for osx10.23 on arm64 - for MariaDB 13.2.0-MariaDB (Source distribution), for osx10.23 (arm64)
--
-- Host: 127.0.0.1    Database: nation    Table: region_areas
-- ------------------------------------------------------
-- Server version	13.1.1-MariaDB

--
-- Current Database: `nation`
--

USE `nation`;

--
-- Table structure for table `region_areas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `region_areas` (
  `region_name` varchar(100) NOT NULL,
  `region_area` decimal(15,2) NOT NULL,
  PRIMARY KEY (`region_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
