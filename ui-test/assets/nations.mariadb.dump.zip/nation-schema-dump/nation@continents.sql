-- MariaDB Shell dump 2.0.1  Distrib Ver 26.11.2 for osx10.23 on arm64 - for MariaDB 13.2.0-MariaDB (Source distribution), for osx10.23 (arm64)
--
-- Host: 127.0.0.1    Database: nation    Table: continents
-- ------------------------------------------------------
-- Server version	13.1.1-MariaDB

--
-- Current Database: `nation`
--

USE `nation`;

--
-- Table structure for table `continents`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `continents` (
  `continent_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`continent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
