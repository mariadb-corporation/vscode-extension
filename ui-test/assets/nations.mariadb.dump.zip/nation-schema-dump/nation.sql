-- MariaDB Shell dump 2.0.1  Distrib Ver 26.11.2 for osx10.23 on arm64 - for MariaDB 13.2.0-MariaDB (Source distribution), for osx10.23 (arm64)
--
-- Host: 127.0.0.1    Database: nation
-- ------------------------------------------------------
-- Server version	13.1.1-MariaDB

--
-- Dumping database 'nation'
--

-- begin database `nation`
CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nation` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
-- end database `nation`


--
-- Current Database: `nation`
--

USE `nation`;

--
-- Dumping sequences for database 'nation'
--


--
-- Current Database: `nation`
--

USE `nation`;

--
-- Dumping events for database 'nation'
--

--
-- Current Database: `nation`
--

USE `nation`;

--
-- Dumping libraries for database 'nation'
--


--
-- Current Database: `nation`
--

USE `nation`;

--
-- Dumping routines for database 'nation'
--

